// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "LimitDashboard",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "LimitDashboard", targets: ["WeeklyLimitApp"])
    ],
    targets: [
        .executableTarget(
            name: "WeeklyLimitApp",
            path: "Sources/WeeklyLimitApp"
        )
    ]
)
