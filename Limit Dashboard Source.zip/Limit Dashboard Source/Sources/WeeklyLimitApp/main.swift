import AppKit
import Combine
import Foundation
import SwiftUI

private let cardSize = CGSize(width: 180, height: 108)
private let cardCornerRadius: CGFloat = 12
private let hoverPassthroughAlpha: CGFloat = 0.18
private let interactionPollInterval: TimeInterval = 0.06

struct QuotaSnapshot: Sendable {
    enum State: Sendable {
        case loading
        case live
        case unavailable
    }

    var state: State
    var remainingPercent: Int?
    var resetAt: Date?
    var planName: String
    var statusText: String
    var errorText: String?

    static let loading = QuotaSnapshot(
        state: .loading,
        remainingPercent: nil,
        resetAt: nil,
        planName: "Plus",
        statusText: "Connecting",
        errorText: nil
    )

    static func unavailable(_ message: String) -> QuotaSnapshot {
        QuotaSnapshot(
            state: .unavailable,
            remainingPercent: nil,
            resetAt: nil,
            planName: "—",
            statusText: "Codex offline",
            errorText: message
        )
    }

    var progress: Double {
        guard let remainingPercent else { return 0 }
        return Double(remainingPercent) / 100
    }

    var remainingText: String {
        guard let remainingPercent else { return "—" }
        return "\(remainingPercent)%"
    }

    var resetText: String {
        guard let resetAt else { return "Reset —" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.timeZone = .current
        formatter.dateFormat = "MM月dd日 · HH:mm"
        return "Reset \(formatter.string(from: resetAt))"
    }
}

@MainActor
final class QuotaStore: ObservableObject {
    @Published private(set) var snapshot = QuotaSnapshot.loading
    @Published private(set) var isRefreshing = false

    private var timer: Timer?
    private var refreshTask: Task<Void, Never>?

    init() {
        refresh()
        timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.refresh()
            }
        }
    }

    deinit {
        timer?.invalidate()
        refreshTask?.cancel()
    }

    func refresh() {
        guard !isRefreshing else { return }
        isRefreshing = true
        refreshTask?.cancel()

        refreshTask = Task { [weak self] in
            do {
                let value = try await Task.detached(priority: .utility) {
                    try CodexAppServerClient().fetchSnapshot()
                }.value
                guard !Task.isCancelled else { return }
                self?.snapshot = value
            } catch {
                guard !Task.isCancelled else { return }
                self?.snapshot = .unavailable(error.localizedDescription)
            }
            self?.isRefreshing = false
        }
    }
}

struct CodexAppServerClient: Sendable {
    enum ClientError: LocalizedError {
        case executableMissing
        case processFailed(String)
        case protocolFailed(String)
        case missingRateLimit

        var errorDescription: String? {
            switch self {
            case .executableMissing:
                return "找不到本机 Codex 服务"
            case .processFailed(let message):
                return message
            case .protocolFailed(let message):
                return message
            case .missingRateLimit:
                return "当前账户没有可用的 Codex 限额数据"
            }
        }
    }

    func fetchSnapshot() throws -> QuotaSnapshot {
        guard let executableURL = resolveExecutable() else {
            throw ClientError.executableMissing
        }

        let process = Process()
        let input = Pipe()
        let output = Pipe()
        let errorOutput = Pipe()
        process.executableURL = executableURL
        process.arguments = ["app-server", "--stdio"]
        process.standardInput = input
        process.standardOutput = output
        process.standardError = errorOutput

        do {
            try process.run()
        } catch {
            throw ClientError.processFailed("无法启动 Codex 服务：(error.localizedDescription)")
        }

        let timeout = DispatchWorkItem {
            if process.isRunning {
                process.terminate()
            }
        }
        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 15, execute: timeout)

        defer {
            timeout.cancel()
            if process.isRunning {
                process.terminate()
            }
            _ = errorOutput.fileHandleForReading.readDataToEndOfFile()
        }

        try send(
            [
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": [
                    "clientInfo": [
                        "name": "limit-dashboard",
                        "title": "Limit Dashboard",
                        "version": "0.1.0"
                    ],
                    "capabilities": ["experimentalApi": true]
                ]
            ],
            to: input.fileHandleForWriting
        )

        var planName = "Plus"
        var rateLimitResult: [String: Any]?
        var buffer = Data()
        let deadline = Date().addingTimeInterval(12)

        while Date() < deadline, process.isRunning {
            let chunk = output.fileHandleForReading.availableData
            if chunk.isEmpty { break }
            buffer.append(chunk)

            while let newline = buffer.firstIndex(of: 0x0A) {
                let line = buffer.prefix(upTo: newline)
                buffer.removeSubrange(...newline)
                guard !line.isEmpty,
                      let message = try? JSONSerialization.jsonObject(with: line) as? [String: Any]
                else { continue }

                let responseID = (message["id"] as? NSNumber)?.intValue
                if responseID == 1 {
                    try send(
                        ["jsonrpc": "2.0", "method": "initialized", "params": [:]],
                        to: input.fileHandleForWriting
                    )
                    try send(
                        [
                            "jsonrpc": "2.0",
                            "id": 2,
                            "method": "account/read",
                            "params": ["refreshToken": true]
                        ],
                        to: input.fileHandleForWriting
                    )
                    try send(
                        [
                            "jsonrpc": "2.0",
                            "id": 3,
                            "method": "account/rateLimits/read",
                            "params": NSNull()
                        ],
                        to: input.fileHandleForWriting
                    )
                } else if responseID == 2,
                          let result = message["result"] as? [String: Any],
                          let account = result["account"] as? [String: Any],
                          let plan = account["planType"] as? String {
                    planName = displayPlanName(plan)
                } else if responseID == 3,
                          let result = message["result"] as? [String: Any] {
                    rateLimitResult = result
                }
            }

            if rateLimitResult != nil { break }
        }

        guard let rateLimitResult else {
            throw ClientError.protocolFailed("Codex 服务没有返回限额数据")
        }
        return try makeSnapshot(from: rateLimitResult, planName: planName)
    }

    private func resolveExecutable() -> URL? {
        var candidates: [String] = []
        if let configured = ProcessInfo.processInfo.environment["CODEX_CLI_PATH"], !configured.isEmpty {
            candidates.append(configured)
        }
        candidates.append(contentsOf: [
            "/Applications/ChatGPT.app/Contents/Resources/codex",
            "/Applications/Codex.app/Contents/Resources/codex",
            "/opt/homebrew/bin/codex",
            "/usr/local/bin/codex"
        ])

        return candidates
            .map(URL.init(fileURLWithPath:))
            .first(where: { FileManager.default.isExecutableFile(atPath: $0.path) })
    }

    private func send(_ payload: [String: Any], to handle: FileHandle) throws {
        let data = try JSONSerialization.data(withJSONObject: payload)
        handle.write(data)
        handle.write(Data([0x0A]))
    }

    private func makeSnapshot(from result: [String: Any], planName: String) throws -> QuotaSnapshot {
        let bucket = ((result["rateLimitsByLimitId"] as? [String: Any])?["codex"] as? [String: Any])
            ?? (result["rateLimits"] as? [String: Any])
        guard let bucket,
              let primary = bucket["primary"] as? [String: Any],
              let used = number(primary["usedPercent"]) else {
            throw ClientError.missingRateLimit
        }

        let remaining = max(0, min(100, 100 - Int(used.rounded())))
        let resetAt = number(primary["resetsAt"]).map(Date.init(timeIntervalSince1970:))
        return QuotaSnapshot(
            state: .live,
            remainingPercent: remaining,
            resetAt: resetAt,
            planName: planName,
            statusText: "Live snapshot",
            errorText: nil
        )
    }

    private func number(_ value: Any?) -> Double? {
        if let value = value as? NSNumber { return value.doubleValue }
        if let value = value as? Double { return value }
        if let value = value as? Int { return Double(value) }
        return nil
    }

    private func displayPlanName(_ rawValue: String) -> String {
        rawValue
            .replacingOccurrences(of: "_", with: " ")
            .split(separator: " ")
            .map { $0.capitalized }
            .joined(separator: " ")
    }
}

struct QuotaCardView: View {
    @ObservedObject var store: QuotaStore

    private let ink = Color(red: 0.96, green: 0.97, blue: 0.99)
    private let soft = Color(red: 0.67, green: 0.71, blue: 0.78)
    private let dim = Color(red: 0.44, green: 0.50, blue: 0.59)
    private let lime = Color(red: 0.78, green: 0.95, blue: 0.42)
    private let blue = Color(red: 0.61, green: 0.72, blue: 1.00)

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 5) {
                Circle()
                    .fill(lime)
                    .frame(width: 6, height: 6)
                    .shadow(color: lime.opacity(0.65), radius: 7)
                Text(store.snapshot.statusText.uppercased())
                    .font(.system(size: 8, weight: .regular, design: .monospaced))
                    .tracking(0.7)
                    .foregroundStyle(dim)
                Spacer(minLength: 0)
            }

            Spacer(minLength: 0)

            HStack(alignment: .center, spacing: 8) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Weekly Limit")
                        .font(.system(size: 12, weight: .medium))
                        .tracking(-0.25)
                        .foregroundStyle(ink)
                        .lineLimit(1)

                    Text("7-day capacity · \(store.snapshot.planName)")
                        .font(.system(size: 8, weight: .regular))
                        .foregroundStyle(soft)
                        .lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                QuotaRingView(
                    progress: store.snapshot.progress,
                    value: store.snapshot.remainingText,
                    ink: ink,
                    soft: soft,
                    lime: lime
                )
            }

            Spacer(minLength: 0)

            Rectangle()
                .fill(Color.white.opacity(0.12))
                .frame(height: 1)

            HStack {
                Text(store.snapshot.resetText)
                    .font(.system(size: 7, weight: .regular, design: .monospaced))
                    .tracking(0.1)
                    .foregroundStyle(soft)
                    .lineLimit(1)
                Spacer(minLength: 0)
            }
            .padding(.top, 6)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .frame(width: cardSize.width, height: cardSize.height)
        .background(cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: cardCornerRadius, style: .continuous))
        .overlay(alignment: .top) {
            LinearGradient(
                colors: [.clear, lime.opacity(0.42), .clear],
                startPoint: .leading,
                endPoint: .trailing
            )
            .frame(height: 1)
            .padding(.horizontal, 22)
        }
        .contextMenu {
            Button("Refresh now") {
                store.refresh()
            }
            Divider()
            Button("Quit Limit Dashboard") {
                NSApp.terminate(nil)
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Limit Dashboard")
        .accessibilityValue("\(store.snapshot.remainingText) remaining")
    }

    private var cardBackground: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.07, green: 0.10, blue: 0.14),
                    Color(red: 0.045, green: 0.065, blue: 0.09)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            RadialGradient(
                colors: [blue.opacity(0.18), .clear],
                center: .topTrailing,
                startRadius: 2,
                endRadius: 120
            )
            RadialGradient(
                colors: [lime.opacity(0.10), .clear],
                center: .bottomLeading,
                startRadius: 2,
                endRadius: 130
            )
        }
    }
}

struct QuotaRingView: View {
    let progress: Double
    let value: String
    let ink: Color
    let soft: Color
    let lime: Color

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.white.opacity(0.09), lineWidth: 6)

            Circle()
                .trim(from: 0, to: progress)
                .stroke(
                    AngularGradient(
                        colors: [lime.opacity(0.88), lime, lime.opacity(0.68)],
                        center: .center
                    ),
                    style: StrokeStyle(lineWidth: 6, lineCap: .butt)
                )
                .rotationEffect(.degrees(-90))

            VStack(spacing: 1) {
                Text("\(value)\u{2009}")
                    .font(.system(size: 11, weight: .medium, design: .default))
                    .tracking(0)
                    .foregroundStyle(ink)
                    .lineLimit(1)
                    .fixedSize(horizontal: true, vertical: false)
                    .padding(.horizontal, 5)
                    .frame(width: 48, height: 17, alignment: .center)
                Text("left")
                    .font(.system(size: 6, weight: .regular))
                    .foregroundStyle(soft)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .multilineTextAlignment(.center)
        }
        .frame(width: 56, height: 56)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Remaining quota")
        .accessibilityValue("\(value) left")
    }
}

final class DraggableHostingView<Content: View>: NSHostingView<Content> {
    private var dragStartLocation: NSPoint?
    private var windowStartOrigin: NSPoint?

    override var mouseDownCanMoveWindow: Bool { true }

    override func mouseDown(with event: NSEvent) {
        dragStartLocation = NSEvent.mouseLocation
        windowStartOrigin = window?.frame.origin
        window?.makeKey()
    }

    override func mouseDragged(with event: NSEvent) {
        guard let dragStartLocation,
              let windowStartOrigin,
              let window else { return }
        let currentLocation = NSEvent.mouseLocation
        window.setFrameOrigin(
            NSPoint(
                x: windowStartOrigin.x + currentLocation.x - dragStartLocation.x,
                y: windowStartOrigin.y + currentLocation.y - dragStartLocation.y
            )
        )
    }

    override func mouseUp(with event: NSEvent) {
        dragStartLocation = nil
        windowStartOrigin = nil
    }
}

@MainActor
final class FloatingPanelController: NSObject, NSWindowDelegate {
    private let panel: NSPanel
    private let store = QuotaStore()
    private let originKey = "WeeklyLimit.windowOrigin"
    private var interactionTimer: Timer?

    override init() {
        panel = NSPanel(
            contentRect: NSRect(origin: .zero, size: cardSize),
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        super.init()

        let hostingView = DraggableHostingView(rootView: QuotaCardView(store: store))
        hostingView.frame = NSRect(origin: .zero, size: cardSize)
        hostingView.wantsLayer = true
        hostingView.layer?.backgroundColor = NSColor.clear.cgColor
        hostingView.layer?.isOpaque = false
        hostingView.layer?.cornerRadius = cardCornerRadius
        hostingView.layer?.cornerCurve = .continuous
        hostingView.layer?.masksToBounds = true
        panel.contentView = hostingView
        panel.delegate = self
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.isFloatingPanel = true
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.becomesKeyOnlyIfNeeded = true
        panel.isMovableByWindowBackground = true
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.titleVisibility = .hidden
        panel.titlebarAppearsTransparent = true
        panel.isReleasedWhenClosed = false
    }

    func show() {
        restorePosition()
        panel.makeKeyAndOrderFront(nil)
        startInteractionMonitoring()
        NSApp.activate(ignoringOtherApps: true)
    }

    func windowDidMove(_ notification: Notification) {
        let origin = panel.frame.origin
        UserDefaults.standard.set([Double(origin.x), Double(origin.y)], forKey: originKey)
    }

    private func startInteractionMonitoring() {
        let timer = Timer(timeInterval: interactionPollInterval, repeats: true) { [weak self] _ in
            self?.updateInteractionState()
        }
        interactionTimer = timer
        RunLoop.main.add(timer, forMode: .common)
        updateInteractionState()
    }

    private func updateInteractionState() {
        let pointerIsInside = panel.frame.contains(NSEvent.mouseLocation)
        let commandIsHeld = CGEventSource.flagsState(.combinedSessionState).contains(.maskCommand)
        let shouldPassThrough = pointerIsInside && !commandIsHeld

        if panel.ignoresMouseEvents != shouldPassThrough {
            panel.ignoresMouseEvents = shouldPassThrough
        }

        let targetAlpha: CGFloat = shouldPassThrough ? hoverPassthroughAlpha : 1
        if abs(panel.alphaValue - targetAlpha) > 0.001 {
            panel.alphaValue = targetAlpha
        }
    }

    private func restorePosition() {
        guard let screen = NSScreen.screens.first ?? NSScreen.main else { return }
        let visible = screen.visibleFrame
        let defaultOrigin = NSPoint(
            x: visible.maxX - cardSize.width - 24,
            y: visible.maxY - cardSize.height - 24
        )

        if let saved = UserDefaults.standard.array(forKey: originKey) as? [Double], saved.count == 2 {
            let maxX = visible.maxX - cardSize.width
            let maxY = visible.maxY - cardSize.height
            let x = min(max(saved[0], visible.minX), maxX)
            let y = min(max(saved[1], visible.minY), maxY)
            panel.setFrameOrigin(NSPoint(x: x, y: y))
        } else {
            panel.setFrameOrigin(defaultOrigin)
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var controller: FloatingPanelController?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        controller = FloatingPanelController()
        controller?.show()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false
    }
}

@main
struct WeeklyLimitMain {
    @MainActor
    static func main() {
        let application = NSApplication.shared
        let delegate = AppDelegate()
        application.delegate = delegate
        application.setActivationPolicy(.accessory)
        application.run()
    }
}
