#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/Limit Dashboard.app"
SDK="${MACOS_SDK_PATH:-/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk}"
MODULE_CACHE="$ROOT/.build/module-cache"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
mkdir -p "$MODULE_CACHE"

swiftc \
  -parse-as-library \
  -swift-version 5 \
  -target arm64-apple-macosx14.0 \
  -sdk "$SDK" \
  -module-cache-path "$MODULE_CACHE" \
  -framework AppKit \
  -framework Combine \
  -framework SwiftUI \
  -O \
  "$ROOT/Sources/WeeklyLimitApp/main.swift" \
  -o "$APP/Contents/MacOS/WeeklyLimit"

cp "$ROOT/Info.plist" "$APP/Contents/Info.plist"
cp "$ROOT/Assets/WeeklyLimit.icns" "$APP/Contents/Resources/WeeklyLimit.icns"
xattr -cr "$APP"
codesign --force --deep --sign - "$APP" >/dev/null

echo "Built: $APP"
